import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Phone, Mail, MapPin, CheckCircle, Users, Award, Clock } from "lucide-react"
import { WorkCarousel } from "@/components/work-carousel"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white backdrop-blur-sm sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img src="/images/3counties-logo.png" alt="3 Counties Building Services Logo" className="h-16 w-auto" />
            </div>
            <nav className="hidden md:flex items-center space-x-6">
              <a href="#about" className="text-foreground hover:text-primary transition-colors font-semibold">
                About
              </a>
              <a href="#contact" className="text-foreground hover:text-primary transition-colors font-semibold">
                Contact
              </a>
            </nav>
            <Button className="hidden md:inline-flex">
              <Phone className="w-4 h-4 mr-2" />
              Call Us Now
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section
        className="relative py-20 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('/beautiful-countryside-landscape-of-three-counties-.png')",
        }}
      >
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 text-balance">
              Quality Building Services Across <span className="text-green-400">Three Counties</span>
            </h1>
            <p className="text-xl text-white/90 mb-8 text-pretty max-w-2xl mx-auto">
              From extensions and renovations to new builds and commercial projects, we deliver exceptional
              craftsmanship with over 20 years of experience.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="text-lg px-8">
                <Phone className="w-5 h-5 mr-2" />
                Call Us Now
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="text-lg px-8 bg-white/10 border-white/30 text-white hover:bg-white/20"
              >
                View Our Work
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Services</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Comprehensive building solutions tailored to your needs
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Home Extensions",
                description: "Single and double-story extensions to expand your living space",
                icon: "🏠",
              },
              {
                title: "Kitchen & Bathroom Renovations",
                description: "Complete refurbishments with modern fixtures and fittings",
                icon: "🔧",
              },
              {
                title: "New Build Construction",
                description: "Custom homes built to your exact specifications",
                icon: "🏗️",
              },
              {
                title: "Commercial Projects",
                description: "Office buildings, retail spaces, and industrial facilities",
                icon: "🏢",
              },
              {
                title: "Roofing Services",
                description: "Repairs, replacements, and maintenance for all roof types",
                icon: "🏠",
              },
              {
                title: "General Maintenance",
                description: "Ongoing property maintenance and repair services",
                icon: "⚒️",
              },
            ].map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="text-4xl mb-4">{service.icon}</div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{service.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Why Choose Us</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Trusted by hundreds of satisfied customers across three counties
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Award className="w-8 h-8 text-primary" />,
                title: "20+ Years Experience",
                description: "Decades of expertise in construction and building services",
              },
              {
                icon: <Users className="w-8 h-8 text-primary" />,
                title: "Skilled Team",
                description: "Qualified tradespeople committed to quality workmanship",
              },
              {
                icon: <CheckCircle className="w-8 h-8 text-primary" />,
                title: "Fully Insured",
                description: "Comprehensive insurance coverage for your peace of mind",
              },
              {
                icon: <Clock className="w-8 h-8 text-primary" />,
                title: "On-Time Delivery",
                description: "Projects completed on schedule and within budget",
              },
            ].map((feature, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Recent Work Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Recent Work</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Take a look at some of our completed projects across the three counties
            </p>
          </div>

          <WorkCarousel />

          <div className="text-center mt-12">
            <Button size="lg">
              <Phone className="w-5 h-5 mr-2" />
              Call Us Now for Your Project
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-card/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Get In Touch</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Ready to start your project? Contact us today for a free consultation and quote
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-2xl font-semibold text-foreground mb-6">Contact Information</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Phone className="w-5 h-5 text-primary" />
                    <span className="text-foreground">01234 567890</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Mail className="w-5 h-5 text-primary" />
                    <span className="text-foreground">info@3countiesbuildingservices.co.uk</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="w-5 h-5 text-primary" />
                    <span className="text-foreground">Serving Hertfordshire, Bedfordshire & Buckinghamshire</span>
                  </div>
                </div>

                <div className="mt-8">
                  <h4 className="text-lg font-semibold text-foreground mb-4">Business Hours</h4>
                  <div className="space-y-2 text-muted-foreground">
                    <p>Monday - Friday: 8:00 AM - 6:00 PM</p>
                    <p>Saturday: 9:00 AM - 4:00 PM</p>
                    <p>Sunday: Emergency calls only</p>
                  </div>
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Request a Quote</CardTitle>
                  <CardDescription>Fill out the form below and we'll get back to you within 24 hours</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-foreground">First Name</label>
                      <input className="w-full mt-1 px-3 py-2 bg-input border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring" />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground">Last Name</label>
                      <input className="w-full mt-1 px-3 py-2 bg-input border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring" />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground">Email</label>
                    <input
                      type="email"
                      className="w-full mt-1 px-3 py-2 bg-input border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground">Phone</label>
                    <input
                      type="tel"
                      className="w-full mt-1 px-3 py-2 bg-input border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground">Project Details</label>
                    <textarea
                      rows={4}
                      className="w-full mt-1 px-3 py-2 bg-input border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                      placeholder="Tell us about your project..."
                    ></textarea>
                  </div>
                  <Button className="w-full">Send Message</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img
                  src="/images/3counties-logo.png"
                  alt="3 Counties Building Services Logo"
                  className="h-8 w-auto brightness-0 invert"
                />
              </div>
              <p className="text-background/80 text-sm">
                Professional building services across Hertfordshire, Bedfordshire, and Buckinghamshire.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-background/80">
                <li>Home Extensions</li>
                <li>Kitchen Renovations</li>
                <li>New Build Construction</li>
                <li>Commercial Projects</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Areas Served</h4>
              <ul className="space-y-2 text-sm text-background/80">
                <li>Hertfordshire</li>
                <li>Bedfordshire</li>
                <li>Buckinghamshire</li>
                <li>Surrounding Areas</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="space-y-2 text-sm text-background/80">
                <p>01234 567890</p>
                <p>info@3countiesbuildingservices.co.uk</p>
              </div>
            </div>
          </div>

          <div className="border-t border-background/20 mt-8 pt-8 text-center text-sm text-background/60">
            <p>&copy; 2025 3 Counties Building Services. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
