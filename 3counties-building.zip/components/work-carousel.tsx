"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const workImages = [
  {
    src: "/images/work/conservatory-extension.jpg",
    alt: "Beautiful brick conservatory extension with French doors and paved patio",
    title: "Conservatory Extension",
  },
  {
    src: "/images/work/modern-conservatory.jpg",
    alt: "White conservatory with glass roof attached to brick house",
    title: "Modern Conservatory",
  },
  {
    src: "/images/work/large-extension.jpg",
    alt: "Large modern extension with floor-to-ceiling windows and dark roof",
    title: "Contemporary Extension",
  },
  {
    src: "/images/work/kitchen-extension.jpg",
    alt: "Modern kitchen extension with bi-fold doors opening to wooden deck",
    title: "Kitchen Extension",
  },
]

export function WorkCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % workImages.length)
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + workImages.length) % workImages.length)
  }

  // Auto-advance carousel
  useEffect(() => {
    const interval = setInterval(nextSlide, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative max-w-4xl mx-auto">
      <div className="relative overflow-hidden rounded-lg shadow-lg">
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {workImages.map((image, index) => (
            <div key={index} className="w-full flex-shrink-0">
              <img src={image.src || "/placeholder.svg"} alt={image.alt} className="w-full h-96 object-cover" />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-6">
                <h3 className="text-white text-xl font-semibold">{image.title}</h3>
              </div>
            </div>
          ))}
        </div>

        {/* Navigation buttons */}
        <Button
          variant="outline"
          size="icon"
          className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
          onClick={prevSlide}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
          onClick={nextSlide}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Dots indicator */}
      <div className="flex justify-center mt-4 space-x-2">
        {workImages.map((_, index) => (
          <button
            key={index}
            className={`w-3 h-3 rounded-full transition-colors ${
              index === currentIndex ? "bg-primary" : "bg-gray-300"
            }`}
            onClick={() => setCurrentIndex(index)}
          />
        ))}
      </div>
    </div>
  )
}
